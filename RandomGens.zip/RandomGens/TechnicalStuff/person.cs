﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomGens
{
    class person
    {
        private string name { get; set; }
        private string species { get; set; }
        private string sex { get; set; }
        private string greeting { get; set; }
        private string farewell { get; set; }
        private string thanks { get; set; }
        private string annoy { get; set; }
        private string job { get; set; }
        private int money { get; set; }
        private List<string> items { get; set; }


    }
}
